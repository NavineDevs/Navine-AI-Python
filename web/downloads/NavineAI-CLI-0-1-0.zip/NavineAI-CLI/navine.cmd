@echo off
setlocal EnableExtensions
set "BIN=%~dp0"
set "ROOT=%NAVINE_ROOT%"
if not defined ROOT if exist "%BIN%..\..\venv\Scripts\python.exe" set "ROOT=%BIN%..\..\"
if not defined ROOT if exist "%BIN%..\venv\Scripts\python.exe" set "ROOT=%BIN%..\"
if not defined ROOT if exist "%CD%\venv\Scripts\python.exe" set "ROOT=%CD%\"
if defined ROOT (
  if exist "%ROOT%venv\Scripts\python.exe" (
    set "PY=%ROOT%venv\Scripts\python.exe"
  ) else (
    set "PY=python"
  )
  cd /d "%ROOT%"
) else (
  set "PY=python"
)
"%PY%" -m navine %*
exit /b %ERRORLEVEL%
