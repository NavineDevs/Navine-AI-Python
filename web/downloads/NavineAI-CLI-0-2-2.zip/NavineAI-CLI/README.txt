Navine AI - Python CLI
Version 0.2.2

Works like Claude / ChatGPT CLI:
  navine                  open interactive chat
  navine "hello"          one-shot prompt
  navine chat             same as bare navine
  navine train list       tool commands

Install (Windows):
  1. Extract this zip
  2. Right-click Install.ps1 -> Run with PowerShell
     or: powershell -ExecutionPolicy Bypass -File Install.ps1
  3. Open a new terminal and type: navine

Manual:
  Add the extracted bin folder to your PATH, or run navine.cmd from that folder.
  Requires this Navine AI - Python project + venv on the machine.
