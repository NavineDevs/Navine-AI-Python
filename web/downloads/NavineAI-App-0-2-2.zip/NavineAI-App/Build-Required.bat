@echo off
echo Navine AI - Python desktop app is not built yet.
echo Run: cd app ^&^& npm run build
pause
